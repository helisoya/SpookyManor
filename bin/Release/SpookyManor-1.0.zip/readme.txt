===== Spooky Manor 1.0 =====
A Game By Helisoya

Goal :

Find the exit of the maze while escaping the various monsters.
The exit is marked on the minimap when you go near it.

Controls :

Arrow Keys = Movement
M = Global Map

